<?php
    $con=mysqli_connect("sql307.epizy.com","epiz_32187154","A5ZwBqGOM8yyBx","epiz_32187154_project") or die('unable to connect');
?>